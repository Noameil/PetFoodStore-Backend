package hackeru.noameil.petfoodstore.repository.Costumer;

import hackeru.noameil.petfoodstore.entity.OrderItem;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.List;

public class CustomerOrderItemRepositoryImp implements CustomerOrderItemRepository {

    @PersistenceContext
    EntityManager entityManager;
    @Override
    public List<OrderItem> getCustomQueryItems() {
        return null;
    }
}
