package hackeru.noameil.petfoodstore.repository.Costumer;

import hackeru.noameil.petfoodstore.entity.OrderItem;

import java.util.List;

public interface CustomerOrderItemRepository {

    List<OrderItem> getCustomQueryItems();
}
